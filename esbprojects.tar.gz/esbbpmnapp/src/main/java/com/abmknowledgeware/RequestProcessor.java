package com.abmknowledgeware;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;


public class RequestProcessor implements Processor{
    @Override
    public void process(Exchange exchange) throws Exception {
        Message inMessage = exchange.getIn();
        String workflowTypeId=(String) inMessage.getHeader("workflowTypeId");
        String currentEscalationIndex=(String) inMessage.getHeader("currentEscalationIndex");
        String serviceEventId=(String) inMessage.getHeader("serviceEventId");
        String serviceEventName=(String) inMessage.getHeader("serviceEventName");
        String orgId=(String) inMessage.getHeader("orgId");
        String serviceId=(String) inMessage.getHeader("serviceId");
        String compTypeId=(String) inMessage.getHeader("compTypeId");
        String deptId=(String) inMessage.getHeader("deptId");
        String codIdOperLevel1=(String) inMessage.getHeader("codIdOperLevel1");
        String codIdOperLevel2=(String) inMessage.getHeader("codIdOperLevel2");
        String codIdOperLevel3=(String) inMessage.getHeader("codIdOperLevel3");
        String codIdOperLevel4=(String) inMessage.getHeader("codIdOperLevel4");
        String codIdOperLevel5=(String) inMessage.getHeader("codIdOperLevel5");
        
        if (workflowTypeId == "")
        	inMessage.setHeader(workflowTypeId, null);
        
        if (currentEscalationIndex == "")
        	inMessage.setHeader(currentEscalationIndex, null);
        
        if (serviceEventId == "")
        	inMessage.setHeader(serviceEventId, null);
        
        if (serviceEventName == "")
        	inMessage.setHeader(serviceEventName, null);
        
        if (orgId == "")
        	inMessage.setHeader(orgId, null);
        
        if (serviceId == "")
        	inMessage.setHeader(serviceId, null);
        
        if (compTypeId == "")
        	inMessage.setHeader(compTypeId, null);
        
        if (deptId == "")
        	inMessage.setHeader(deptId, null);
        
        if (codIdOperLevel1 == "")
        	inMessage.setHeader(codIdOperLevel1, null);
        
        if (codIdOperLevel2 == "")
        	inMessage.setHeader(codIdOperLevel2, null);
        
        if (codIdOperLevel3 == "")
        	inMessage.setHeader(codIdOperLevel3, null);
        
        if (codIdOperLevel4 == "")
        	inMessage.setHeader(codIdOperLevel4, null);
        
        if (codIdOperLevel5 == "")
        	inMessage.setHeader(codIdOperLevel5, null);
        
    }
        
    }
