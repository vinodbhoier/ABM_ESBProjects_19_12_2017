package com.abmknowledgeware;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.message.MessageContentsList;
import org.apache.log4j.Logger;
import org.restlet.util.Series;

public class RequestProcessor  implements Processor{
    @Override
    public void process(Exchange exchange) throws Exception {
       	Logger log = Logger.getLogger(RequestProcessor.class);
        Message inMessage = exchange.getIn();
        String bodyPara = exchange.getIn().getBody(String.class);
        System.out.println("bodyPara"+bodyPara);
        //inMessage.setHeader(CxfConstants.OPERATION_NAME, "Submit");
        //inMessage.setHeader(CxfConstants.OPERATION_NAMESPACE, "urn:orangescape");
        //inMessage.setHeader("Authorization", "bWJhQHVsYi5jb206MTIz");
    }
        
    }
